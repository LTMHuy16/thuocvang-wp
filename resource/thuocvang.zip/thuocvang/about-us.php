<?php /* Template Name: About Us */ ?>

<?php get_header(); ?>

<main>
    
    <?php include(get_theme_file_path('sections/banners/index.php')); ?>
    <?php include(get_theme_file_path('sections/index.php')); ?>
    
</main>

<?php get_footer(); ?>